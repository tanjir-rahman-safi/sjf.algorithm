#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of process: ";
    cin >> n;


    int p[n], bt[n], wt[n], tat[n];
    float avg_wt = 0, avg_tat = 0;
    int total_wt = 0, total_tat = 0;


    cout << "Enter Burst Time:" << endl;

    for (int i = 0; i < n; i++)

    {
        cout << "P" << i + 1 << ": ";

        cin >> bt[i];

        p[i] = i + 1;
    }


    for (int i = 0; i < n; i++)
    {
        int index = i;
        for (int j = i + 1; j < n; j++)
            if (bt[j] < bt[index])
                index = j;
        swap(bt[i], bt[index]);
        swap(p[i], p[index]);
    }

    wt[0] = 0;


    for (int i = 1; i < n; i++)
    {
        wt[i] = bt[i-1] + wt[i-1];
        total_wt += wt[i];
    }
    avg_wt = (float)total_wt / (float)n;


    for (int i = 0; i < n; i++)
    {
        tat[i] = bt[i] + wt[i];
        total_tat += tat[i];
    }
    avg_tat = (float)total_tat / (float)n;



    cout << "P\tBT\tWT\tTAT" << endl;

    for (int i = 0; i < n; i++)

    {
        cout << p[i] << "\t" << bt[i] << "\t" << wt[i] << "\t" << tat[i] << endl;
    }

    cout << "Average Waiting Time= " << avg_wt << endl;

    cout << "Average Turnaround Time= " << avg_tat << endl;

    return 0;
}
